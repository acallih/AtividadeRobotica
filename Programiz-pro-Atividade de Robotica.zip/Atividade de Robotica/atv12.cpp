void dobrar(int* p) {
    *p *= 2;
}