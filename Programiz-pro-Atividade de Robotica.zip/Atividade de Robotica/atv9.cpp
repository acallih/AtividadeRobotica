int quadrado(int n) {
    return n * n;
}