void incrementar(int* p) {
    (*p)++;
}