float calcularAreaRetangulo(float base, float altura) {
    return base * altura;
}
