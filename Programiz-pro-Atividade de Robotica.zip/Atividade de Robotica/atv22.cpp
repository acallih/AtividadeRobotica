int exercicio22() {
    const float BONUS = 500.0;
    float salario;
    cin >> salario;
    cout << "Salario final: " << salario + BONUS << endl;
    return 0;
}