void alterarValores(int valor, int &ref) {
    valor = 10;
    ref = 20;
}