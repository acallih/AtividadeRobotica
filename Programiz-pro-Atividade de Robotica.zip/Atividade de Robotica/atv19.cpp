float media(float a, float b, float c) {
    return (a + b + c) / 3;
}