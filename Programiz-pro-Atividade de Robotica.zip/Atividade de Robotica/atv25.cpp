
void saque(float valor) {
    if (valor <= saldo) saldo -= valor;
}

void deposito(float valor) {
    saldo += valor;
}

void consulta() {
    cout << saldo << endl;
}