void menu() {
    int op, a, b;
    cin >> op >> a >> b;
    if (op == 1) cout << soma(a, b);
    else if (op == 2) cout << a - b;
    else if (op == 3) cout << a * b;
}

float saldo = 1000;
