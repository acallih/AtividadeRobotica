int exercicio4() {
    int i = 5;
    float f = 5.5;
    double d = 5.55555;
    cout << i / 2 << " " << f / 2 << " " << d / 2 << endl;
    return 0;
}