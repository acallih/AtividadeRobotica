int exercicio5() {
    string nome;
    int idade;
    cin >> nome >> idade;
    cout << "Olá, " << nome << ". Você tem " << idade << " anos." << endl;
    return 0;
}