int exercicio3() {
    const float PI = 3.14;
    float raio;
    cin >> raio;
    cout << "Area: " << PI * raio * raio << endl;
    return 0;
}