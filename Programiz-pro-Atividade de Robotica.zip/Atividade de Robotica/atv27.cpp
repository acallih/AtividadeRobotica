void trocarValores(void* a, void* b, string tipo) {
    if (tipo == "int") {
        int* x = (int*)a;
        int* y = (int*)b;
        int temp = *x;
        *x = *y;
        *y = temp;
    } else if (tipo == "float") {
        float* x = (float*)a;
        float* y = (float*)b;
        float temp = *x;
        *x = *y;
        *y = temp;
    }
}