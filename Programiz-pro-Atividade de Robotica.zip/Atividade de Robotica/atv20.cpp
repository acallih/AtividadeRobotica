void situacao(string nome, float nota) {
    cout << nome << (nota >= 7 ? " está aprovado" : " está reprovado") << endl;
}