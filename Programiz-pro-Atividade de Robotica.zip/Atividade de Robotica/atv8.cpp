void mostrarMensagem() {
    cout << "Bem-vindo ao programa!" << endl;
}