bool ehPar(int n) {
    return n % 2 == 0;
}