int exercicio11() {
    int x = 10;
    int* p = &x;
    cout << *p << " - Endereco: " << p << endl;
    return 0;
}