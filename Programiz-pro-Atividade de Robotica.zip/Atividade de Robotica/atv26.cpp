struct Pessoa {
    string nome;
    int idade;
    float altura;
};

void mostrarPessoa(Pessoa* p) {
    cout << p->nome << " " << p->idade << " " << p->altura << endl;
}