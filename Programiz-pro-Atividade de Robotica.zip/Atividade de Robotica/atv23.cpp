float calcularMediaVetor(int* v, int tamanho) {
    int soma = 0;
    for (int i = 0; i < tamanho; i++) soma += v[i];
    return soma / (float)tamanho;
}

void inverterSinal(int &valor) {
    valor = -valor;
}