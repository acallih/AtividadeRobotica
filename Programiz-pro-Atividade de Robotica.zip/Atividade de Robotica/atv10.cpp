float maior(float a, float b) {
    return (a > b) ? a : b;
}